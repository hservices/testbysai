import { Component } from '@angular/core';
import { NavController,IonicPage,ToastController } from 'ionic-angular';
import { ShoppingListService } from '../../services/shopping-list/shopping-list.service';
import { Observable } from 'rxjs/Observable';
import { Item } from '../../models/item/item.model';
import { Change } from '@firebase/database/dist/esm/src/core/view/Change';
import { AngularFireAuth } from 'angularfire2/auth';


@IonicPage()
@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  shoppingList$ :Observable<Item[]>;

  constructor(public navCtrl: NavController, private shopping:ShoppingListService,private afAuth:AngularFireAuth,private tost:ToastController) {
      this.shoppingList$=this.shopping.getShoppingList().snapshotChanges().map(
        Change=>{
           return Change.map(c=>({
             key:c.payload.key, ...c.payload.val()
           })).reverse();
        }
      )
  }

  ionViewWillLoad() {
   this.afAuth.authState.subscribe(data =>{
     if(data && data.email && data.uid){
     this.tost.create({
       message:`welcome to PMS,${data.email}`,
       duration:3000
     }).present();
    }
    else{
      this.tost.create({
        message:`Invalid Credientails /n Try Again`,
        duration:3000
      }).present();
    }
   });
  }
}
