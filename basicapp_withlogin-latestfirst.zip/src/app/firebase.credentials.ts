export const FIREBASE_CONFIG ={
    apiKey: "AIzaSyAsI80JatCCiE4gZWqgHB9ve_ZMWsOGNAk",
    authDomain: "pms-voterdb.firebaseapp.com",
    databaseURL: "https://pms-voterdb.firebaseio.com",
    projectId: "pms-voterdb",
    storageBucket: "pms-voterdb.appspot.com",
    messagingSenderId: "351902668008"
  };