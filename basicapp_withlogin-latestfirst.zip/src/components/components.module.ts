import { NgModule } from '@angular/core';
import { GoogleLoginComponent } from './google-login/google-login';
@NgModule({
	declarations: [GoogleLoginComponent],
	imports: [],
	exports: [GoogleLoginComponent]
})
export class ComponentsModule {}
