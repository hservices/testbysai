export interface Item{
    key?:string;
    name: string;
    quantity:number;
    price: number;
}