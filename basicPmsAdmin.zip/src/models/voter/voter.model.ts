export interface Voter{
    key?:string;
    voterName: string;
    voterID:string;
    adharID: string;
    voterRole:string;

}